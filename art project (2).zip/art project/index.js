require('dotenv').config();

// English: make sure that the .env is installed along with this. Follow the comment in that file to see where to put your bot token! (Do this before running bot)
// Español: asegúrese de que el .env esté instalado junto con esto. ¡Siga el comentario en ese archivo para ver dónde poner su token de bot!

const { Client, DiscordAPIError } = require('discord.js'); 
const client = new Client({ partials: ['MESSAGE']});
const { MessageEmbed } = require('discord.js');
const PREFIX = ""; 

// English: these four are some basic things you should have inside your discord.js bot, you can take them out if you like/don't need them. some are needed though!
// English: put prefix inside the parentheses (character 15-16, line 6)
// Español: Estas cuatro son algunas cosas básicas que debe tener dentro de su bot discord.js, puede eliminarlas si las desea o no las necesita. aunque algunos son necesarios!
// Español: poner prefijo entre paréntesis (carácter 15-16, línea 6)

client.login(process.env.BOT_TOKEN)

client.on('ready', () => {
    console.log(`-------------------------------------------`)
    console.log(`| logged in? = true ######################|`)
    console.log(`| bot username? = ${client.user.username} ################ |`)
    console.log(`| Prefix? is : "${PREFIX}" ###################### |`)
    console.log(`-------------------------------------------`)
    console.log(`summery: ${client.user.username} is online!`)
});

client.on("message", message => {
 
    if (message.author.bot) return;

    if (message.content === 'hi') {
        message.channel.send("Hello!")
    }

})

// basic text command, no prefix ^^^