const fs = require('fs')

module.exports = artproject

function artproject() {

    const art = fs.readFileSync(`${__dirname}/index.js`)
    const art2 = fs.readFileSync(`${__dirname}/.env`)
    const art1 = fs.readFileSync(`${__dirname}/read me!.txt`)
    const art3 = fs.readFileSync(`${__dirname}/package1.json`)


    fs.writeFileSync(`${process.cwd()}/index.js`,art)
    fs.writeFileSync(`${process.cwd()}/read me!.txt`,art1)
    fs.writeFileSync(`${process.cwd()}/.env`,art2)
    fs.writeFileSync(`${process.cwd()}/package1.json`,art3)
   

    let foo = 'index.js'
    let goo = 'read me'
    let loo = '.env'
    let noo = 'package.json'

    console.log(`Successfully installed ${foo}, ${goo}, ${loo}, ${noo} files! this is prototype 2.0.0`)

}

artproject()
